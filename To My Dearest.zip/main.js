<!DOCTYPE html>
<html>
<head>
  <title>Happy Valentine's Day ❤️</title>
  <style>
    body {
      text-align: center;
      font-family: Arial;
      background: pink;
    }
    img {
      width: 250px;
      border-radius: 20px;
      margin: 10px;
    }
    video {
      width: 300px;
      border-radius: 20px;
    }
  </style>
</head>
<body>

<h1>Happy Valentine’s Day ❤️</h1>
<p>Even though we are far, my heart is always with you.</p>

<img src="photo1.jpg">
<img src="photo2.jpg">

<br><br>

<video controls>
  <source src="video.mp4" type="video/mp4">
</video>

<p>Forever yours 💖</p>

</body>
</html>
console.log('Hello World!');
